package com.example.myapp

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.OnMapReadyCallback
import org.maplibre.android.maps.Style
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.PropertyFactory.*
import org.maplibre.android.style.sources.GeoJsonSource
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipInputStream
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

class MainActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var mapView: MapView
    private var map: MapLibreMap? = null
    private var currentGeoJson = JSONObject("""{"type":"FeatureCollection","features":[]}""")
    private val sourceId = "myapp-data"
    private val lineLayerId = "myapp-lines"

    private val importFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importUri(uri)
    }
    private val exportFile = registerForActivityResult(ActivityResultContracts.CreateDocument("application/geo+json")) { uri ->
        if (uri != null) exportGeoJson(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 8)
        }
        val importBtn = Button(this).apply { text = "ورود فایل GIS" }
        val exportBtn = Button(this).apply { text = "خروجی GeoJSON" }
        val addBtn = Button(this).apply { text = "افزودن نمونه خط" }
        toolbar.addView(importBtn, LinearLayout.LayoutParams(0, -2, 1f))
        toolbar.addView(exportBtn, LinearLayout.LayoutParams(0, -2, 1f))
        toolbar.addView(addBtn, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(toolbar)
        mapView = MapView(this)
        root.addView(mapView, LinearLayout.LayoutParams(-1, 0, 1f))
        val status = TextView(this).apply {
            text = "myApp • نمونه اولیه GIS آفلاین/آنلاین"
            setPadding(12, 8, 12, 8)
        }
        root.addView(status)
        setContentView(root)
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync(this)

        importBtn.setOnClickListener { importFile.launch(arrayOf("*/*")) }
        exportBtn.setOnClickListener { exportFile.launch("myapp-project.geojson") }
        addBtn.setOnClickListener { addDemoLine(); status.text = "خط نمونه اضافه شد؛ برای ماندگاری خروجی بگیرید." }
    }

    override fun onMapReady(mapLibreMap: MapLibreMap) {
        map = mapLibreMap
        mapLibreMap.cameraPosition = CameraPosition.Builder()
            .target(LatLng(35.700, 51.400)).zoom(10.0).build()
        mapLibreMap.setStyle(Style.Builder().fromUri("https://demotiles.maplibre.org/style.json")) { style ->
            style.addSource(GeoJsonSource(sourceId, currentGeoJson.toString()))
            style.addLayer(LineLayer(lineLayerId, sourceId).withProperties(
                lineColor("#E4572E"), lineWidth(4f), lineOpacity(0.9f)
            ))
        }
    }

    private fun importUri(uri: Uri) {
        try {
            val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) c.getString(i) else ""
            } ?: ""
            val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            val text = when {
                name.endsWith(".kmz", true) || bytes.take(2).toByteArray().contentEquals(byteArrayOf(0x50, 0x4b)) ->
                    unzipKml(bytes)
                name.endsWith(".kml", true) || String(bytes).contains("<kml", true) ->
                    kmlToGeoJson(String(bytes))
                else -> String(bytes, Charsets.UTF_8)
            }
            val parsed = JSONObject(text)
            require(parsed.optString("type") == "FeatureCollection") {
                "فعلاً ورودی GeoJSON باید از نوع FeatureCollection باشد."
            }
            currentGeoJson = parsed
            refreshSource()
            Toast.makeText(this, "فایل وارد شد: ${parsed.optJSONArray("features")?.length() ?: 0} عارضه", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در ورود فایل: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun unzipKml(bytes: ByteArray): String {
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.name.endsWith(".kml", true)) {
                    val out = ByteArrayOutputStream()
                    zip.copyTo(out)
                    return kmlToGeoJson(out.toString("UTF-8"))
                }
            }
        }
        error("در فایل KMZ فایل KML پیدا نشد.")
    }

    // Prototype converter: supports KML Point and LineString placemarks; polygon support is planned.
    private fun kmlToGeoJson(kml: String): String {
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(kml.reader())
        val features = org.json.JSONArray()
        var name = "عارضه"
        var inPlacemark = false
        var geometryType = ""
        var coordinates = ""
        var description = ""
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            if (parser.eventType == XmlPullParser.START_TAG) {
                when (parser.name) {
                    "Placemark" -> { inPlacemark = true; name = "عارضه"; geometryType = ""; coordinates = ""; description = "" }
                    "name" -> if (inPlacemark) { parser.next(); name = parser.text ?: name }
                    "description" -> if (inPlacemark) { parser.next(); description = parser.text ?: "" }
                    "Point" -> if (inPlacemark) geometryType = "Point"
                    "LineString" -> if (inPlacemark) geometryType = "LineString"
                    "coordinates" -> if (inPlacemark) { parser.next(); coordinates = parser.text ?: "" }
                }
            } else if (parser.eventType == XmlPullParser.END_TAG && parser.name == "Placemark" && inPlacemark) {
                val coords = coordinates.trim().split(Regex("\\s+")).mapNotNull { token ->
                    val p = token.split(",")
                    if (p.size >= 2) try { org.json.JSONArray().put(p[0].toDouble()).put(p[1].toDouble()) } catch (_: Exception) { null } else null
                }
                if (geometryType == "Point" && coords.isNotEmpty()) {
                    val geom = JSONObject().put("type", "Point").put("coordinates", coords[0])
                    features.put(feature(name, description, geom))
                } else if (geometryType == "LineString" && coords.size >= 2) {
                    val arr = org.json.JSONArray()
                    coords.forEach { arr.put(it) }
                    features.put(feature(name, description, JSONObject().put("type", "LineString").put("coordinates", arr)))
                }
                inPlacemark = false
            }
            parser.next()
        }
        return JSONObject().put("type", "FeatureCollection").put("features", features).toString()
    }

    private fun feature(name: String, description: String, geometry: JSONObject) =
        JSONObject().put("type", "Feature")
            .put("properties", JSONObject().put("name", name).put("description", description))
            .put("geometry", geometry)

    private fun addDemoLine() {
        val features = currentGeoJson.optJSONArray("features") ?: org.json.JSONArray()
        val coords = org.json.JSONArray()
            .put(org.json.JSONArray().put(51.38).put(35.69))
            .put(org.json.JSONArray().put(51.42).put(35.72))
        features.put(feature("معبر نمونه", "قابل ویرایش در نسخه بعد", JSONObject().put("type", "LineString").put("coordinates", coords)))
        currentGeoJson.put("features", features)
        refreshSource()
    }

    private fun refreshSource() {
        map?.getStyle { style ->
            (style.getSource(sourceId) as? GeoJsonSource)?.setGeoJson(currentGeoJson.toString())
        }
    }

    private fun exportGeoJson(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(currentGeoJson.toString(2).toByteArray(Charsets.UTF_8)) }
            Toast.makeText(this, "خروجی GeoJSON ذخیره شد.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "خطا در خروجی: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onStart() { super.onStart(); mapView.onStart() }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onDestroy() { mapView.onDestroy(); super.onDestroy() }
}
